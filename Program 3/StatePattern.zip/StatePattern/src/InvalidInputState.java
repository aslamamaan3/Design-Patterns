class InvalidInputState implements State{
	public void nextState(Context ctx, char inputchar){}

}