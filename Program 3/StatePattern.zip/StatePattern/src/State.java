public interface State{
	public void nextState(Context ctx, char inputchar);
}