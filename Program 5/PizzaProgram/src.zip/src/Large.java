
public class Large implements Pizza {

	@Override
	public String getDesc() {
		
		return "Large with ";
	}

	@Override
	public double getCost() {

		return 12.00;
	}

}
