
public abstract class ToppingDecorator implements Pizza {
	public abstract String getDesc();
	public abstract double getCost();
}
