
public interface Pizza {
	
	public abstract String getDesc();
	public abstract double getCost();

}
