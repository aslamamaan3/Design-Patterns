
public class Medium implements Pizza {

	@Override
	public String getDesc() {
		
		return "Medium with ";
	}

	@Override
	public double getCost() {

		return 10.00;
	}

}
