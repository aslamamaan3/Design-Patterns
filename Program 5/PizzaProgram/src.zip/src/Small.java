
public class Small implements Pizza {

	@Override
	public String getDesc() {
		
		return "Small with ";
	}

	@Override
	public double getCost() {
		
		return 8.00;
	}

}
