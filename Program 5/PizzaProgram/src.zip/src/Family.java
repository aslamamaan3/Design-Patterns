
public class Family implements Pizza {

	@Override
	public String getDesc() {

		return "Family with ";
	}

	@Override
	public double getCost() {

		return 16.00;
	}

}
